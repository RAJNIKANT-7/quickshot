#!/usr/bin/env bash
# Builds QuickShot.apk (needs Android SDK build-tools + platform 33, and JDK 17+).
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
BT="$SDK/build-tools/$(ls "$SDK/build-tools" | sort -V | tail -1)"
JAR="$SDK/platforms/android-33/android.jar"
[ -f "$JAR" ] || { echo "Missing $JAR (install platform android-33)"; exit 1; }
rm -rf out && mkdir -p out/classes
"$BT/aapt2" compile --dir res -o out/res.zip
"$BT/aapt2" link -o out/base.apk -I "$JAR" --manifest AndroidManifest.xml \
  --min-sdk-version 30 --target-sdk-version 33 --version-code 4 --version-name 1.3 out/res.zip
javac --release 8 -nowarn -cp "$JAR" -d out/classes src/com/quickshot/*.java
"$BT/d8" --lib "$JAR" --min-api 30 --output out $(find out/classes -name '*.class')
(cd out && zip -q -u base.apk classes.dex)
"$BT/zipalign" -f 4 out/base.apk out/aligned.apk
KS=quickshot.keystore
[ -f "$KS" ] || keytool -genkeypair -keystore "$KS" -storepass quickshot -keypass quickshot \
  -alias quickshot -keyalg RSA -keysize 2048 -validity 36500 -dname "CN=QuickShot"
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:quickshot --key-pass pass:quickshot \
  --out QuickShot.apk out/aligned.apk
echo "Built: $(pwd)/QuickShot.apk"
