package com.quickshot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.app.Dialog;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int BG = 0xFF0B0B0D, CARD = 0xFF151517, STROKE = 0xFF2A2A2E;
    static final int RED = 0xFFE5252A, MUTED = 0xFF9A9AA2, GREEN = 0xFF2ECC71;
    private static final int COLS = 4, PREVIEW_ROWS = 2, MAX_SHOWN = 80;

    private LinearLayout root;
    private boolean showAll = false, askedDialogOpen = false;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    // ------------------------------------------------------------ helpers
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable box(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private TextView pill(String label, boolean filled, View.OnClickListener c) {
        TextView t = text(label, 14, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setBackground(filled ? box(RED, 12, 0) : box(0, 12, 0xFF3A3A40));
        t.setOnClickListener(c);
        return t;
    }

    private View iconCircle(int type, int color, int fill, int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        f.setBackground(g);
        f.addView(new IconView(this, type, color), new FrameLayout.LayoutParams(-1, -1));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    private boolean serviceEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName() + "/");
    }

    private String label(File f) {
        long t;
        try { t = Long.parseLong(f.getName().replace(".jpg", "")); } catch (Exception e) { t = f.lastModified(); }
        long now = System.currentTimeMillis();
        TimeZone tz = TimeZone.getDefault();
        long diff = (now + tz.getOffset(now)) / 86400000L - (t + tz.getOffset(t)) / 86400000L;
        if (diff <= 0) return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(t));
        if (diff == 1) return "Yesterday";
        return diff + " days ago";
    }

    private void openA11y() { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }

    private void needService() {
        Toast.makeText(this, "Turn on QuickShot in Accessibility settings first", Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(ShotService.PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setBackgroundDrawable(new ColorDrawable(BG));
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ShotService.onChange = new Runnable() { public void run() { build(); } };
        build();
        // First launch: explain and take the user straight to Accessibility settings (asked once).
        if (!serviceEnabled() && !prefs.getBoolean("asked", false) && !askedDialogOpen) {
            askedDialogOpen = true;
            prefs.edit().putBoolean("asked", true).apply();
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Enable QuickShot")
                    .setMessage("QuickShot needs the Accessibility permission to show the floating button and "
                            + "take screenshots. It never reads or stores anything else on your screen.\n\n"
                            + "On the next screen: Installed apps \u203A QuickShot \u203A turn ON.")
                    .setNegativeButton("Later", null)
                    .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { openA11y(); }
                    })
                    .setOnDismissListener(new DialogInterface.OnDismissListener() {
                        public void onDismiss(DialogInterface d) { askedDialogOpen = false; }
                    })
                    .show();
        }
    }

    @Override
    protected void onPause() {
        ShotService.onChange = null;
        super.onPause();
    }

    // ------------------------------------------------------------ screen
    private void build() {
        root.removeAllViews();
        addHeader();
        if (!serviceEnabled()) addSetupCard();
        addHero();
        addTiles();
        addRecents();
    }

    private void addHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("logo", "drawable", getPackageName()));
        logo.setColorFilter(RED);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        h.addView(logo, new LinearLayout.LayoutParams(dp(30), dp(38)));

        SpannableStringBuilder sb = new SpannableStringBuilder("QuickShot");
        sb.setSpan(new ForegroundColorSpan(RED), 5, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView title = text("", 22, Color.WHITE, true);
        title.setText(sb);
        title.setPadding(dp(10), 0, 0, 0);
        h.addView(title);

        h.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));

        IconView gear = new IconView(this, Icons.GEAR, MUTED);
        gear.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openA11y(); } });
        h.addView(gear, new LinearLayout.LayoutParams(dp(40), dp(40)));
        root.addView(h, lp(-1, -2, 0, 0, 0, 0));
    }

    private void addSetupCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(box(CARD, 16, STROKE));
        c.addView(text("Finish setup (one time)", 16, Color.WHITE, true));
        TextView body = text("1. Open App Info \u203A \u22EE menu \u203A \"Allow restricted settings\" (if shown).\n"
                + "2. Open Accessibility Settings \u203A Installed apps \u203A QuickShot \u203A turn ON.", 13, MUTED, false);
        body.setPadding(0, dp(6), 0, dp(4));
        c.addView(body);
        c.addView(pill("Open App Info", false, new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            }
        }), lp(-1, -2, 0, 8, 0, 0));
        c.addView(pill("Open Accessibility Settings", true, new View.OnClickListener() {
            public void onClick(View v) { openA11y(); }
        }), lp(-1, -2, 0, 8, 0, 0));
        root.addView(c, lp(-1, -2, 0, 14, 0, 0));
    }

    private void addHero() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(16), dp(20), dp(16), dp(22));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF3B1215, 0xFF160A0B});
        g.setCornerRadius(dp(20));
        g.setStroke(dp(1), 0xFF5C1A1E);
        hero.setBackground(g);

        FrameLayout glow = new FrameLayout(this);
        GradientDrawable og = new GradientDrawable();
        og.setShape(GradientDrawable.OVAL);
        og.setColor(0x26E5252A);
        glow.setBackground(og);
        View btn = iconCircle(Icons.CAMERA, Color.WHITE, RED, 76);
        glow.addView(btn, new FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER));
        hero.addView(glow, new LinearLayout.LayoutParams(dp(104), dp(104)));

        TextView t = text("Take Screenshot", 20, Color.WHITE, true);
        t.setPadding(0, dp(10), 0, 0);
        hero.addView(t);
        hero.addView(text("Capture your screen instantly", 13, MUTED, false));

        hero.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ShotService s = ShotService.instance;
                if (s == null) { needService(); return; }
                moveTaskToBack(true);        // step aside, then capture the screen behind the app
                s.captureFromApp();
            }
        });
        root.addView(hero, lp(-1, -2, 0, 16, 0, 0));
    }

    private void addTile(LinearLayout row, int index, int icon, int iconColor, String name, String sub,
                         View.OnClickListener c) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setPadding(dp(6), dp(14), dp(6), dp(12));
        tile.setBackground(box(CARD, 16, STROKE));
        tile.addView(iconCircle(icon, iconColor, (iconColor & 0x00FFFFFF) | 0x33000000, 44));
        TextView lbl = text(name, 12, Color.WHITE, false);
        lbl.setGravity(Gravity.CENTER);
        lbl.setPadding(0, dp(8), 0, 0);
        tile.addView(lbl);
        TextView sb = text(sub, 11, iconColor == GREEN ? GREEN : MUTED, false);
        sb.setGravity(Gravity.CENTER);
        tile.addView(sb);
        tile.setOnClickListener(c);
        LinearLayout.LayoutParams tp = lp(0, -2, index == 0 ? 0 : 5, 0, index == 2 ? 0 : 5, 0);
        tp.weight = 1f;
        row.addView(tile, tp);
    }

    private void addTiles() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        ShotService s = ShotService.instance;
        final boolean btnOn = serviceEnabled() && (s == null || s.isBarEnabled())
                && prefs.getBoolean(ShotService.K_ON, true);

        addTile(row, 0, Icons.PDF, RED, "Save as PDF", "Name & save", new View.OnClickListener() {
            public void onClick(View v) {
                ShotService sv = ShotService.instance;
                if (sv == null) needService(); else sv.requestPdf();
            }
        });
        addTile(row, 1, Icons.POWER, btnOn ? GREEN : MUTED, "Floating Button", btnOn ? "ON" : "OFF",
                new View.OnClickListener() {
                    public void onClick(View v) {
                        ShotService sv = ShotService.instance;
                        if (sv == null) {
                            prefs.edit().putBoolean(ShotService.K_ON, !prefs.getBoolean(ShotService.K_ON, true)).apply();
                            needService();
                            build();
                            return;
                        }
                        sv.setBarEnabled(!sv.isBarEnabled());
                        build();
                    }
                });
        addTile(row, 2, Icons.TRASH, MUTED, "Delete All", "Clear captures", new View.OnClickListener() {
            public void onClick(View v) {
                final int n = ShotService.shots(MainActivity.this).size();
                if (n == 0) { Toast.makeText(MainActivity.this, "Nothing to delete", Toast.LENGTH_SHORT).show(); return; }
                new AlertDialog.Builder(MainActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setMessage("Delete all " + n + " screenshots? Save as PDF first if you still need them.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                ShotService sv = ShotService.instance;
                                if (sv != null) sv.clearAll();
                                else {
                                    for (File f : ShotService.shots(MainActivity.this)) f.delete();
                                    build();
                                }
                            }
                        }).show();
            }
        });
        root.addView(row, lp(-1, -2, 0, 14, 0, 0));
    }

    private void addRecents() {
        final List<File> all = ShotService.shots(this);
        Collections.reverse(all);   // newest first
        int n = all.size();

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("Recent Captures", 16, Color.WHITE, true));
        head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        if (n > COLS * PREVIEW_ROWS) {
            TextView more = text(showAll ? "Show less \u2039" : "View All \u203A", 13, RED, false);
            more.setPadding(dp(8), dp(4), 0, dp(4));
            more.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { showAll = !showAll; build(); }
            });
            head.addView(more);
        } else {
            head.addView(text(n + (n == 1 ? " capture" : " captures"), 13, MUTED, false));
        }
        root.addView(head, lp(-1, -2, 0, 24, 0, 0));

        if (n == 0) {
            TextView e = text("No captures yet.\nTap \"Take Screenshot\" or use the floating button.", 13, MUTED, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(dp(12), dp(28), dp(12), dp(28));
            e.setBackground(box(CARD, 16, STROKE));
            root.addView(e, lp(-1, -2, 0, 10, 0, 0));
            return;
        }

        int gap = 8;
        int cellW = (getResources().getDisplayMetrics().widthPixels - dp(36) - dp(gap) * (COLS - 1)) / COLS;
        int shown = showAll ? Math.min(n, MAX_SHOWN) : Math.min(n, COLS * PREVIEW_ROWS);
        for (int start = 0; start < shown; start += COLS) {
            LinearLayout row = new LinearLayout(this);
            for (int c = 0; c < COLS; c++) {
                int i = start + c;
                View cell = i < shown ? makeCell(all.get(i), cellW) : new View(this);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(cellW, ViewGroup.LayoutParams.WRAP_CONTENT);
                p.setMargins(0, 0, c == COLS - 1 ? 0 : dp(gap), 0);
                row.addView(cell, p);
            }
            root.addView(row, lp(-1, -2, 0, 8, 0, 0));
        }
    }

    private View makeCell(final File f, int cellW) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(dp(3), dp(3), dp(3), dp(2));
        cell.setBackground(box(CARD, 10, STROKE));

        final ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0xFF1E1E22);
        iv.setClipToOutline(true);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(8));
            }
        });
        int iw = cellW - dp(6);
        cell.addView(iv, new LinearLayout.LayoutParams(iw, (int) (iw * 1.35f)));

        TextView lbl = text(label(f), 10, MUTED, false);
        lbl.setGravity(Gravity.CENTER);
        lbl.setPadding(0, dp(3), 0, dp(3));
        cell.addView(lbl);

        final String key = f.getPath() + f.lastModified();
        iv.setTag(key);
        Bitmap cached = cache.get(key);
        if (cached != null) iv.setImageBitmap(cached);
        else bg.execute(new Runnable() {
            public void run() {
                final Bitmap b = decode(f, 270);
                if (b == null) return;
                cache.put(key, b);
                ui.post(new Runnable() {
                    public void run() { if (key.equals(iv.getTag())) iv.setImageBitmap(b); }
                });
            }
        });

        cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { viewShot(f); } });
        return cell;
    }

    private Bitmap decode(File f, int targetW) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getPath(), o);
        int s = 1;
        while (o.outWidth / (s * 2) >= targetW) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        return BitmapFactory.decodeFile(f.getPath(), o2);
    }

    private void viewShot(final File f) {
        final Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        final ImageView iv = new ImageView(this);
        iv.setBackgroundColor(Color.BLACK);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        bg.execute(new Runnable() {
            public void run() {
                final Bitmap b = decode(f, 1080);
                ui.post(new Runnable() { public void run() { if (d.isShowing() && b != null) iv.setImageBitmap(b); } });
            }
        });
        iv.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
        iv.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(MainActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setMessage("Delete this screenshot?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface x, int w) {
                                f.delete();
                                d.dismiss();
                                ShotService sv = ShotService.instance;
                                if (sv != null) sv.refreshCount(); else build();
                            }
                        }).show();
                return true;
            }
        });
        d.setContentView(iv);
        d.show();
        Toast.makeText(this, "Tap to close \u2022 Long-press to delete", Toast.LENGTH_SHORT).show();
    }
}
