package com.quickshot;

import android.accessibilityservice.AccessibilityService;
import android.animation.ValueAnimator;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Display;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ShotService extends AccessibilityService {
    static final String PREFS = "qs", K_ON = "bar_on", K_RIGHT = "fab_right", K_Y = "fab_y";
    private static final float IDLE_ALPHA = 0.42f, TOUCH_ALPHA = 1f;
    private static final int RED = 0xFFE5252A;

    static volatile ShotService instance;
    static volatile Runnable onChange;

    private WindowManager wm;
    private FrameLayout fab;
    private TextView badge;
    private WindowManager.LayoutParams fabLp;
    private LinearLayout menu;
    private SharedPreferences prefs;
    private int fabSize;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();     // screenshots
    private final ExecutorService pdfIo = Executors.newSingleThreadExecutor();  // pdf / delete

    private volatile boolean busy = false, pdfBusy = false, fromApp = false;
    private boolean capturing = false, hold = false, on = true;

    // ------------------------------------------------------------ storage (shared with the app)
    /** Persistent app storage - NOT cache, so Android can never clear screenshots on its own. */
    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "shots");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Oldest first (file names are timestamps). Only fully-written .jpg files count. */
    static List<File> shots(Context c) {
        File[] fs = dir(c).listFiles();
        List<File> out = new ArrayList<File>();
        if (fs != null) {
            Arrays.sort(fs);
            for (File f : fs) if (f.getName().endsWith(".jpg") && f.length() > 0) out.add(f);
        }
        return out;
    }

    static String defaultName() {
        return "Screenshots_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
    }

    static String cleanName(String s) {
        if (s == null) s = "";
        s = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.toLowerCase(Locale.ROOT).endsWith(".pdf")) s = s.substring(0, s.length() - 4).trim();
        if (s.length() > 80) s = s.substring(0, 80).trim();
        if (s.isEmpty() || s.equals(".")) s = defaultName();
        return s;
    }

    // ------------------------------------------------------------ lifecycle
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        on = prefs.getBoolean(K_ON, true);
        addOverlay();
        pdfIo.execute(new Runnable() {   // move shots from the old cache location, if any
            public void run() {
                File[] old = new File(getCacheDir(), "shots").listFiles();
                if (old != null) for (File f : old) {
                    if (f.getName().endsWith(".jpg")) f.renameTo(new File(dir(ShotService.this), f.getName()));
                }
                refreshCount();
            }
        });
        refreshCount();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        hideMenu();
        placeFab();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        teardown();
        io.shutdown();
        pdfIo.shutdown();
        super.onDestroy();
    }

    private void teardown() {
        if (instance == this) instance = null;
        hideMenu();
        if (fab != null && wm != null) {
            try { wm.removeView(fab); } catch (Exception ignored) { }
        }
        fab = null;
    }

    // ------------------------------------------------------------ overlay
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Rect bounds() { return wm.getCurrentWindowMetrics().getBounds(); }

    private class FabView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        FabView(Context c) { super(c); }
        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy) - dp(1);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xF2121214);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(RED);
            c.drawCircle(cx, cy, r - dp(1), p);
            p.setColor(Color.WHITE);
            Icons.draw(c, Icons.CAMERA, cx, cy, r * 0.42f, p);
        }
    }

    private void addOverlay() {
        if (fab != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        fabSize = dp(52);

        fab = new FrameLayout(this);
        FabView btn = new FabView(this);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER);
        fab.addView(btn, bp);

        badge = new TextView(this);
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(9);
        badge.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setMinWidth(dp(16));
        badge.setPadding(dp(3), 0, dp(3), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(RED);
        bg.setCornerRadius(dp(8));
        badge.setBackground(bg);
        badge.setVisibility(View.GONE);
        fab.addView(badge, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(16),
                Gravity.TOP | Gravity.END));

        fab.setAlpha(IDLE_ALPHA);
        fab.setOnTouchListener(new FabTouch());

        fabLp = new WindowManager.LayoutParams(fabSize, fabSize,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        fabLp.gravity = Gravity.TOP | Gravity.START;
        placeFab();
        wm.addView(fab, fabLp);
        applyVisibility();
    }

    private void placeFab() {
        if (fab == null || wm == null) return;
        Rect b = bounds();
        boolean right = prefs.getBoolean(K_RIGHT, true);
        float fy = prefs.getFloat(K_Y, 0.35f);
        fabLp.x = right ? b.width() - fabSize : 0;
        fabLp.y = Math.max(0, Math.min((int) (fy * b.height()), b.height() - fabSize));
        if (fab.isAttachedToWindow()) {
            try { wm.updateViewLayout(fab, fabLp); } catch (Exception ignored) { }
        }
    }

    private void applyVisibility() {
        if (fab == null) return;
        if (!on || hold) fab.setVisibility(View.GONE);
        else fab.setVisibility(capturing ? View.INVISIBLE : View.VISIBLE);
    }

    // public controls used by the app / dialog
    boolean isBarEnabled() { return on; }

    void setBarEnabled(boolean v) {
        on = v;
        if (prefs != null) prefs.edit().putBoolean(K_ON, v).apply();
        hideMenu();
        applyVisibility();
    }

    void setHold(final boolean v) {
        main.post(new Runnable() {
            public void run() { hold = v; hideMenu(); applyVisibility(); }
        });
    }

    // ------------------------------------------------------------ touch: tap = shot, hold = menu, drag = move
    private class FabTouch implements View.OnTouchListener {
        private float downX, downY;
        private int startX, startY;
        private boolean moved, longFired;
        private final Runnable longRunner = new Runnable() {
            public void run() {
                if (!moved) {
                    longFired = true;
                    if (fab != null) fab.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showMenu();
                }
            }
        };

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            if (fab == null) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = fabLp.x; startY = fabLp.y;
                    moved = false; longFired = false;
                    fab.animate().alpha(TOUCH_ALPHA).setDuration(100).start();
                    main.postDelayed(longRunner, 450);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float mx = e.getRawX() - downX, my = e.getRawY() - downY;
                    if (!moved && Math.hypot(mx, my) > dp(8)) {
                        moved = true;
                        main.removeCallbacks(longRunner);
                        hideMenu();
                    }
                    if (moved) {
                        Rect b = bounds();
                        fabLp.x = Math.max(0, Math.min(startX + (int) mx, b.width() - fabSize));
                        fabLp.y = Math.max(0, Math.min(startY + (int) my, b.height() - fabSize));
                        try { wm.updateViewLayout(fab, fabLp); } catch (Exception ignored) { }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    main.removeCallbacks(longRunner);
                    fab.animate().alpha(IDLE_ALPHA).setDuration(250).start();
                    if (moved) snapToEdge();
                    else if (!longFired) {
                        if (menu != null) hideMenu(); else capture();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    main.removeCallbacks(longRunner);
                    fab.animate().alpha(IDLE_ALPHA).setDuration(250).start();
                    if (moved) snapToEdge();
                    return true;
            }
            return false;
        }
    }

    private void snapToEdge() {
        final Rect b = bounds();
        final boolean right = fabLp.x + fabSize / 2 > b.width() / 2;
        final int from = fabLp.x, to = right ? b.width() - fabSize : 0;
        prefs.edit().putBoolean(K_RIGHT, right)
                .putFloat(K_Y, fabLp.y / (float) b.height()).apply();
        ValueAnimator a = ValueAnimator.ofInt(from, to);
        a.setDuration(160);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator va) {
                if (fab == null) return;
                fabLp.x = (Integer) va.getAnimatedValue();
                try { wm.updateViewLayout(fab, fabLp); } catch (Exception ignored) { }
            }
        });
        a.start();
    }

    // ------------------------------------------------------------ hold menu (2 extra options)
    private LinearLayout pill(int icon, String label, int accent, View.OnClickListener c) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(dp(10), dp(8), dp(16), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF2151517);
        g.setCornerRadius(dp(24));
        g.setStroke(dp(1), accent);
        l.setBackground(g);
        l.addView(new IconView(this, icon, accent), new LinearLayout.LayoutParams(dp(26), dp(26)));
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(dp(8), 0, 0, 0);
        l.addView(t);
        l.setOnClickListener(c);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(0, dp(3), 0, dp(3));
        l.setLayoutParams(p);
        return l;
    }

    private final Runnable autoHide = new Runnable() { public void run() { hideMenu(); } };

    private void showMenu() {
        if (fab == null || menu != null) return;
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.addView(pill(Icons.PDF, "Save as PDF", RED, new View.OnClickListener() {
            public void onClick(View v) { hideMenu(); requestPdf(); }
        }));
        menu.addView(pill(Icons.TRASH, "Delete all", 0xFF9A9AA2, new View.OnClickListener() {
            public void onClick(View v) { hideMenu(); requestClear(); }
        }));
        menu.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) hideMenu();
                return false;
            }
        });
        menu.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int mw = menu.getMeasuredWidth(), mh = menu.getMeasuredHeight();
        Rect b = bounds();
        boolean left = fabLp.x + fabSize / 2 > b.width() / 2;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-2, -2,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = left ? fabLp.x - mw - dp(6) : fabLp.x + fabSize + dp(6);
        lp.y = Math.max(0, Math.min(fabLp.y + fabSize / 2 - mh / 2, b.height() - mh));
        menu.setAlpha(0f);
        menu.setScaleX(0.85f);
        menu.setScaleY(0.85f);
        try {
            wm.addView(menu, lp);
            menu.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(130).start();
            main.postDelayed(autoHide, 5000);
        } catch (Exception ex) { menu = null; }
    }

    private void hideMenu() {
        main.removeCallbacks(autoHide);
        if (menu != null && wm != null) {
            try { wm.removeView(menu); } catch (Exception ignored) { }
        }
        menu = null;
    }

    // ------------------------------------------------------------ helpers
    private void toast(final String s, final boolean lng) {
        main.post(new Runnable() {
            public void run() { Toast.makeText(ShotService.this, s, lng ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show(); }
        });
    }

    void refreshCount() {
        final int n = shots(this).size();
        main.post(new Runnable() {
            public void run() {
                if (badge != null) {
                    badge.setText(String.valueOf(n));
                    badge.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
                }
                Runnable r = onChange;
                if (r != null) r.run();
            }
        });
    }

    private void pulse() {
        main.post(new Runnable() {
            public void run() {
                if (fab == null) return;
                fab.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                fab.animate().scaleX(1.2f).scaleY(1.2f).setDuration(90).withEndAction(new Runnable() {
                    public void run() { if (fab != null) fab.animate().scaleX(1f).scaleY(1f).setDuration(120).start(); }
                }).start();
            }
        });
    }

    private void launchDialog(String mode) {
        Intent i = new Intent(this, DialogActivity.class);
        i.putExtra(DialogActivity.EXTRA_MODE, mode);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    void requestPdf() {
        if (pdfBusy) { toast("Already saving a PDF\u2026", false); return; }
        if (shots(this).isEmpty()) { toast("No screenshots yet", false); return; }
        launchDialog(DialogActivity.MODE_PDF);
    }

    void requestClear() {
        if (shots(this).isEmpty()) { toast("Nothing to delete", false); return; }
        launchDialog(DialogActivity.MODE_CLEAR);
    }

    // ------------------------------------------------------------ capture
    /** Called from the app: the app minimizes first, then we capture what is behind it. */
    void captureFromApp() {
        fromApp = true;
        main.postDelayed(new Runnable() { public void run() { capture(); } }, 750);
    }

    void capture() {
        if (busy) return;
        busy = true;
        capturing = true;
        hideMenu();
        applyVisibility();               // button vanishes so it never appears in the shot
        main.postDelayed(new Runnable() { public void run() { doCapture(0); } }, 160);
    }

    private void endCapture() {
        capturing = false;
        applyVisibility();
    }

    private void doCapture(final int attempt) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, io, new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult result) {
                    main.post(new Runnable() { public void run() { endCapture(); } });
                    saveShot(result);
                }

                @Override
                public void onFailure(final int code) {
                    if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT && attempt < 3) {
                        main.postDelayed(new Runnable() { public void run() { doCapture(attempt + 1); } }, 1050);
                        return;
                    }
                    fromApp = false;
                    busy = false;
                    main.post(new Runnable() { public void run() { endCapture(); } });
                    if (code == ERROR_TAKE_SCREENSHOT_SECURE_WINDOW) toast("This screen blocks screenshots", false);
                    else toast("Screenshot failed (code " + code + ")", false);
                }
            });
        } catch (Exception ex) {
            fromApp = false;
            busy = false;
            endCapture();
            toast("Screenshot error: " + ex.getMessage(), false);
        }
    }

    private boolean compressTo(Bitmap bmp, File f) {
        try {
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f), 64 * 1024);
            boolean ok = bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos);
            bos.flush();
            bos.close();
            return ok && f.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** Runs on the io thread. Writes to .tmp then renames, so a shot is never half-saved. */
    private void saveShot(ScreenshotResult result) {
        HardwareBuffer hb = null;
        Bitmap hw = null;
        try {
            hb = result.getHardwareBuffer();
            hw = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
            if (hw == null) throw new IOException("no image data");
            String base = String.format(Locale.US, "%015d", System.currentTimeMillis());
            File tmp = new File(dir(this), base + ".tmp");
            File out = new File(dir(this), base + ".jpg");
            boolean ok = compressTo(hw, tmp);
            if (!ok) {
                Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                if (sw != null) { ok = compressTo(sw, tmp); sw.recycle(); }
            }
            if (!ok || !tmp.renameTo(out)) { tmp.delete(); throw new IOException("could not save image"); }
            pulse();
            if (fromApp) toast("Screenshot saved", false);
            refreshCount();
        } catch (Exception ex) {
            toast("Save failed: " + ex.getMessage(), false);
        } finally {
            fromApp = false;
            if (hw != null) hw.recycle();
            if (hb != null) hb.close();
            busy = false;
        }
    }

    // ------------------------------------------------------------ delete all (after confirmation)
    void clearAll() {
        pdfIo.execute(new Runnable() {
            public void run() {
                for (File f : shots(ShotService.this)) f.delete();
                refreshCount();
                toast("All screenshots deleted", false);
            }
        });
    }

    // ------------------------------------------------------------ PDF
    /**
     * Saves every screenshot taken so far as one PDF in Downloads. Screenshots are deleted ONLY
     * after the PDF is fully written and verified; on any failure they all stay safely on disk.
     */
    void savePdf(String rawName) {
        if (pdfBusy) { toast("Already saving a PDF\u2026", false); return; }
        final List<File> files = shots(this);
        if (files.isEmpty()) { toast("No screenshots yet", false); return; }
        pdfBusy = true;
        toast("Creating PDF\u2026", false);
        final String name = cleanName(rawName) + ".pdf";
        pdfIo.execute(new Runnable() {
            public void run() {
                ContentResolver cr = getContentResolver();
                Uri uri = null;
                try {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new IOException("could not create file in Downloads");
                    OutputStream os = cr.openOutputStream(uri, "w");
                    if (os == null) throw new IOException("could not open file");
                    try { writePdf(files, os); } finally { os.close(); }

                    long size = 0;
                    AssetFileDescriptor fd = cr.openAssetFileDescriptor(uri, "r");
                    if (fd != null) { size = fd.getLength(); fd.close(); }
                    if (size < 200) throw new IOException("PDF came out empty");

                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    cr.update(uri, done, null, null);

                    String shown = name;
                    Cursor c = cr.query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
                    if (c != null) { if (c.moveToFirst()) shown = c.getString(0); c.close(); }

                    for (File f : files) f.delete();   // safe: PDF verified
                    refreshCount();
                    pulse();
                    toast("Saved to Downloads/" + shown, true);
                } catch (Exception ex) {
                    if (uri != null) { try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { } }
                    toast("PDF failed (" + ex.getMessage() + "). Your screenshots are safe \u2013 try again.", true);
                } finally {
                    pdfBusy = false;
                }
            }
        });
    }

    private static class Out {
        final OutputStream os;
        long pos = 0;
        Out(OutputStream o) { os = new BufferedOutputStream(o, 64 * 1024); }
        void s(String t) throws IOException {
            byte[] b = t.getBytes("ISO-8859-1");
            os.write(b);
            pos += b.length;
        }
        void file(File f) throws IOException {
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] buf = new byte[64 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) { os.write(buf, 0, r); pos += r; }
            } finally { in.close(); }
        }
    }

    /** Streams JPEG files straight into a PDF (one page each) - tiny memory use. */
    private void writePdf(List<File> all, OutputStream raw) throws IOException {
        List<File> files = new ArrayList<File>();
        List<int[]> dims = new ArrayList<int[]>();
        for (File f : all) {
            BitmapFactory.Options op = new BitmapFactory.Options();
            op.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), op);
            if (op.outWidth > 0 && op.outHeight > 0) { files.add(f); dims.add(new int[]{op.outWidth, op.outHeight}); }
        }
        int n = files.size();
        if (n == 0) throw new IOException("no readable screenshots");

        Out o = new Out(raw);
        int total = 3 * n + 3;
        long[] off = new long[total];

        o.s("%PDF-1.4\n");
        off[1] = o.pos;
        o.s("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
        StringBuilder kids = new StringBuilder();
        for (int i = 0; i < n; i++) kids.append(5 + 3 * i).append(" 0 R ");
        off[2] = o.pos;
        o.s("2 0 obj\n<< /Type /Pages /Kids [" + kids + "] /Count " + n + " >>\nendobj\n");

        for (int i = 0; i < n; i++) {
            File f = files.get(i);
            int w = dims.get(i)[0], h = dims.get(i)[1];
            String W = String.format(Locale.US, "%.2f", w * 0.75f);
            String H = String.format(Locale.US, "%.2f", h * 0.75f);
            int imgId = 3 + 3 * i, conId = 4 + 3 * i, pgId = 5 + 3 * i;

            off[imgId] = o.pos;
            o.s(imgId + " 0 obj\n<< /Type /XObject /Subtype /Image /Width " + w + " /Height " + h
                    + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length "
                    + f.length() + " >>\nstream\n");
            o.file(f);
            o.s("\nendstream\nendobj\n");

            String c = "q " + W + " 0 0 " + H + " 0 0 cm /Im0 Do Q";
            off[conId] = o.pos;
            o.s(conId + " 0 obj\n<< /Length " + c.length() + " >>\nstream\n" + c + "\nendstream\nendobj\n");

            off[pgId] = o.pos;
            o.s(pgId + " 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + W + " " + H
                    + "] /Resources << /XObject << /Im0 " + imgId + " 0 R >> >> /Contents "
                    + conId + " 0 R >>\nendobj\n");
        }

        long xref = o.pos;
        o.s("xref\n0 " + total + "\n0000000000 65535 f \n");
        for (int k = 1; k < total; k++) o.s(String.format(Locale.US, "%010d 00000 n \n", off[k]));
        o.s("trailer\n<< /Size " + total + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF");
        o.os.flush();
    }
}
