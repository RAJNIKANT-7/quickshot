package com.quickshot;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small floating dialog used by the overlay button: asks for the PDF name, or confirms delete-all. */
public class DialogActivity extends Activity {
    static final String EXTRA_MODE = "mode", MODE_PDF = "pdf", MODE_CLEAR = "clear";
    private boolean done = false;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ShotService s = ShotService.instance;
        if (s == null) { finish(); return; }
        s.setHold(true);               // overlay button steps aside while the dialog is open
        show(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        done = false;
        show(i);
    }

    @Override
    protected void onDestroy() {
        ShotService s = ShotService.instance;
        if (s != null) s.setHold(false);
        super.onDestroy();
    }

    private GradientDrawable box(int fill, int r, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView btn(String label, boolean filled, View.OnClickListener c) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(15);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(13), dp(8), dp(13));
        t.setBackground(filled ? box(MainActivity.RED, 12, 0) : box(0, 12, 0xFF3A3A40));
        t.setOnClickListener(c);
        return t;
    }

    private void show(Intent in) {
        final ShotService svc = ShotService.instance;
        if (svc == null) { finish(); return; }
        final boolean pdf = !MODE_CLEAR.equals(in.getStringExtra(EXTRA_MODE));
        int n = ShotService.shots(this).size();
        if (n == 0) { finish(); return; }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xAA000000);
        root.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }     // tap outside = cancel (nothing is lost)
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(18));
        card.setBackground(box(MainActivity.CARD, 20, 0xFF3A1417));
        card.setClickable(true);

        TextView title = new TextView(this);
        title.setText(pdf ? "Save as PDF" : "Delete all screenshots?");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(title);

        TextView sub = new TextView(this);
        String cnt = n + (n == 1 ? " screenshot" : " screenshots");
        sub.setText(pdf ? cnt + " will be combined into one PDF in Downloads."
                : cnt + " will be permanently deleted. Save as PDF first if you still need them.");
        sub.setTextColor(MainActivity.MUTED);
        sub.setTextSize(13);
        sub.setPadding(0, dp(6), 0, dp(14));
        card.addView(sub);

        final EditText et = new EditText(this);
        if (pdf) {
            et.setText(ShotService.defaultName());
            et.setHint("File name");
            et.setHintTextColor(0xFF6A6A72);
            et.setTextColor(Color.WHITE);
            et.setTextSize(16);
            et.setSingleLine(true);
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            et.setImeOptions(EditorInfo.IME_ACTION_DONE);
            et.setSelectAllOnFocus(true);
            et.setPadding(dp(14), dp(12), dp(14), dp(12));
            et.setBackground(box(0xFF0B0B0D, 12, 0xFF2A2A2E));
            et.setHighlightColor(0x66E5252A);
            card.addView(et, new LinearLayout.LayoutParams(-1, -2));
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final View.OnClickListener go = new View.OnClickListener() {
            public void onClick(View v) {
                if (done) return;
                done = true;
                ShotService s = ShotService.instance;
                if (s != null) { if (pdf) s.savePdf(et.getText().toString()); else s.clearAll(); }
                finish();
            }
        };
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 1f);
        a.setMargins(0, 0, dp(5), 0);
        LinearLayout.LayoutParams c2 = new LinearLayout.LayoutParams(0, -2, 1f);
        c2.setMargins(dp(5), 0, 0, 0);
        row.addView(btn("Cancel", false, new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        }), a);
        row.addView(btn(pdf ? "Save" : "Delete", true, go), c2);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(16);
        card.addView(row, rp);

        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int id, android.view.KeyEvent e) {
                if (id == EditorInfo.IME_ACTION_DONE) { go.onClick(v); return true; }
                return false;
            }
        });

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        cp.setMargins(dp(24), dp(24), dp(24), dp(24));
        root.addView(card, cp);
        setContentView(root);

        if (pdf) {
            et.requestFocus();
            et.postDelayed(new Runnable() {
                public void run() {
                    InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (im != null) im.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
                }
            }, 150);
        }
    }
}
