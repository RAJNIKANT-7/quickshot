package com.quickshot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Tiny vector icon set drawn with Canvas (no emoji, crisp at any density, zero assets). */
final class Icons {
    static final int CAMERA = 0, PDF = 1, POWER = 2, TRASH = 3, GEAR = 4;

    static void draw(Canvas c, int type, float cx, float cy, float s, Paint p) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * 0.17f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        RectF r = new RectF();
        Path path = new Path();
        switch (type) {
            case CAMERA:
                r.set(cx - s, cy - s * 0.55f, cx + s, cy + s * 0.75f);
                c.drawRoundRect(r, s * 0.25f, s * 0.25f, p);
                path.moveTo(cx - s * 0.4f, cy - s * 0.55f);
                path.lineTo(cx - s * 0.2f, cy - s * 0.9f);
                path.lineTo(cx + s * 0.2f, cy - s * 0.9f);
                path.lineTo(cx + s * 0.4f, cy - s * 0.55f);
                c.drawPath(path, p);
                c.drawCircle(cx, cy + s * 0.1f, s * 0.37f, p);
                break;
            case PDF:
                path.moveTo(cx - s * 0.7f, cy - s);
                path.lineTo(cx + s * 0.2f, cy - s);
                path.lineTo(cx + s * 0.7f, cy - s * 0.5f);
                path.lineTo(cx + s * 0.7f, cy + s);
                path.lineTo(cx - s * 0.7f, cy + s);
                path.close();
                c.drawPath(path, p);
                c.drawLine(cx + s * 0.2f, cy - s, cx + s * 0.2f, cy - s * 0.5f, p);
                c.drawLine(cx + s * 0.2f, cy - s * 0.5f, cx + s * 0.7f, cy - s * 0.5f, p);
                c.drawLine(cx - s * 0.35f, cy + s * 0.1f, cx + s * 0.35f, cy + s * 0.1f, p);
                c.drawLine(cx - s * 0.35f, cy + s * 0.5f, cx + s * 0.35f, cy + s * 0.5f, p);
                break;
            case POWER:
                r.set(cx - s * 0.85f, cy - s * 0.8f, cx + s * 0.85f, cy + s * 0.9f);
                c.drawArc(r, -55, 290, false, p);
                c.drawLine(cx, cy - s, cx, cy - s * 0.1f, p);
                break;
            case TRASH:
                c.drawLine(cx - s * 0.9f, cy - s * 0.6f, cx + s * 0.9f, cy - s * 0.6f, p);
                c.drawLine(cx - s * 0.3f, cy - s * 0.6f, cx - s * 0.3f, cy - s * 0.95f, p);
                c.drawLine(cx + s * 0.3f, cy - s * 0.6f, cx + s * 0.3f, cy - s * 0.95f, p);
                c.drawLine(cx - s * 0.3f, cy - s * 0.95f, cx + s * 0.3f, cy - s * 0.95f, p);
                path.moveTo(cx - s * 0.65f, cy - s * 0.6f);
                path.lineTo(cx - s * 0.55f, cy + s);
                path.lineTo(cx + s * 0.55f, cy + s);
                path.lineTo(cx + s * 0.65f, cy - s * 0.6f);
                c.drawPath(path, p);
                c.drawLine(cx - s * 0.2f, cy - s * 0.2f, cx - s * 0.2f, cy + s * 0.6f, p);
                c.drawLine(cx + s * 0.2f, cy - s * 0.2f, cx + s * 0.2f, cy + s * 0.6f, p);
                break;
            case GEAR:
                c.drawCircle(cx, cy, s * 0.36f, p);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
                    c.drawLine(cx + cs * s * 0.62f, cy + sn * s * 0.62f,
                            cx + cs * s * 0.95f, cy + sn * s * 0.95f, p);
                }
                c.drawCircle(cx, cy, s * 0.66f, p);
                break;
        }
    }

    private Icons() { }
}

class IconView extends View {
    private final int type;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    IconView(Context ctx, int type, int color) {
        super(ctx);
        this.type = type;
        p.setColor(color);
    }

    void setColor(int color) { p.setColor(color); invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight()) * 0.34f;
        Icons.draw(c, type, getWidth() / 2f, getHeight() / 2f, s, p);
    }
}
